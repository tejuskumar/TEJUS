# Verilog-CodeGen
This a mini tool which will generate your desired Verilog Code. Feel free to use and share it with others
